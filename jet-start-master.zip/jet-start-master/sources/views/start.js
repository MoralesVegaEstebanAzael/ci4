export default {
	template:"Start page", css:"webix_shadow_medium app_start"
};
